//$(function() {
//
//    console.log("2");
//    var availableTags = [
//        "ActionScript",
//        "AppleScript",
//        "Asp",
//        "BASIC",
//        "C",
//        "C++",
//        "Clojure",
//        "COBOL",
//        "ColdFusion",
//        "Erlang",
//        "Fortran",
//        "Groovy",
//        "Haskell",
//        "Java",
//        "JavaScript",
//        "Lisp",
//        "Perl",
//        "PHP",
//        "Python",
//        "Ruby",
//        "Scala",
//        "Scheme"
//    ];
////    $(document).ready(function () {
////        ("#tags1").autocomplete({
////            source: availableTags
////        });
////        ("#tags2").autocomplete({
////            source: availableTags
////        });
////    });
//});