$(document).ready(function() {
    $("#submit12345").click(function () {
        console.log("my name is ashish");
        var entity1 = (document.getElementById("Entityname").value);
        console.log(entity1);
    });
});